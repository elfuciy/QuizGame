//
//  LeaderBoardController.swift
//  QuizGameMidApp
//
//  Created by Elsever on 11.01.25.
//

import UIKit

class LeaderBoardController: UIViewController {

    @IBOutlet weak var table: UITableView!
    
    var helper = FileManagerHelper()
    var userArray = [UserModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.dataSource = self
        table.delegate = self
        readData()
        table.register(UINib(nibName: "LeaderBoardCell", bundle: nil), forCellReuseIdentifier: "LeaderBoardCell")
    }
    
    func readData() {
        helper.readData { user in
            userArray = user
            userArray.sort(by: { $0.point ?? 0 > $1.point ?? 0 })
        }
    }
}

extension LeaderBoardController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        userArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = table.dequeueReusableCell(withIdentifier: "LeaderBoardCell", for: indexPath) as! LeaderBoardCell
        cell.configure(user: userArray[indexPath.row], index: indexPath.row)
        return cell
    }
    
    
}
