//
//  QuizController.swift
//  QuizGameMidApp
//
//  Created by Elsever on 01.01.25.
//

import UIKit
import CoreData

class QuizController: UIViewController {
    @IBOutlet private weak var buttonView: UIView!
    @IBOutlet private weak var buttonViewShade: UIView!
    @IBOutlet private weak var questionNum: UILabel!
    @IBOutlet private weak var question: UILabel!
    @IBOutlet private weak var firstOptionView: UIView!
    @IBOutlet private weak var firstOptionViewShade: UIView!
    @IBOutlet private weak var secondOptionView: UIView!
    @IBOutlet private weak var secondOptionViewShade: UIView!
    @IBOutlet private weak var thirdOptionView: UIView!
    @IBOutlet private weak var thirdOptionViewShade: UIView!
    @IBOutlet private weak var firstOption: UILabel!
    @IBOutlet private weak var secondOption: UILabel!
    @IBOutlet private weak var thirdOption: UILabel!
    @IBOutlet private weak var timeLabel: UILabel!
    @IBOutlet private weak var barView: UIView!
    @IBOutlet private weak var coinImage: UIImageView!
    @IBOutlet private weak var pointLabel: UILabel!
    
    var context = AppDelegate().persistentContainer.viewContext

    var questions = QuestionDataClass(context: AppDelegate().persistentContainer.viewContext)
    var options = OptionsDataClass(context: AppDelegate().persistentContainer.viewContext)
    var category = CategoryData(context: AppDelegate().persistentContainer.viewContext)
    
    var helper = FileManagerHelper()
    var optionsArray = [OptionsData]()
    var questionArray = [Questions]()
    var userArray = [UserModel]()
    var categoryArray = [QuizCategory]()
    
    var selectedCategory: String?
    var answeredQuestionsNum = 0 //number of questions were answered
    var percent: Double = 0
    var points: Int16 = 0
    var time = 30
    var endTimer: Timer = Timer()
    var timer: Timer = Timer()
    
    var callBack: (([QuizCategory]) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configure()
        getData()
        quizStart()
        navigationItem.leftBarButtonItem = UIBarButtonItem(barButtonSystemItem: .close, target: self, action: #selector(endQuiz))
    }
    
    func configure() {
        ColorConfigurations().circleSecond(view: barView, percent: 100)
        ColorConfigurations().backgroundColor(view)
        coinImage.image = UIImage(named: "coin3")
        buttonView.isHidden = true
        buttonViewShade.isHidden = true
        timeLabel.text = "\(time)"
//        pointLabel.text = userArr
    }
    
    @objc func timeCounter() {
        time -= 1
        let percent = (Double(time) / 30) * 2
        timeLabel.text = "\(time)"
        ColorConfigurations().circleSecond(view: barView, percent: percent)
    }
    
    func getData() {
        category.fetch { category in
            answeredQuestionsNum = Int(category.filter { $0.category == selectedCategory && $0.user == UserDefaults.standard.string(forKey: "username")}.first?.lastQuestion ?? 0)
            categoryArray = category.filter { $0.user == UserDefaults.standard.string(forKey: "username")}
            callBack?(categoryArray)
        }
        
        questions.fetching { question in
            questionArray = question.filter { $0.category == selectedCategory}
            questionArray.sort { $0.id < $1.id }
        }
        
        options.fetch { options in
            optionsArray = options.filter { $0.category == selectedCategory}
        }
        
        helper.readData(completion: { user in
            userArray = user
        })
    }
    
    func quizStart() {
        let category = selectedCategory ?? ""
        if answeredQuestionsNum == 20 {
            let alert = UIAlertController(title: "Quiz finished", message: "You have completed \(questionArray.count) questions", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                self.updateData()
                self.navigationController?.popViewController(animated: true)
            }))
            present(alert, animated: true, completion: nil)
        } else {
            questionNum.text = "Question \(answeredQuestionsNum + 1) of \(questionArray.count)"
            if questionArray[answeredQuestionsNum].category == category && optionsArray[answeredQuestionsNum].category == category {
                question.text = questionArray[answeredQuestionsNum].question
                firstOption.text = optionsArray[answeredQuestionsNum].options
                secondOption.text = optionsArray[answeredQuestionsNum].option2
                thirdOption.text = optionsArray[answeredQuestionsNum].option3
            }
            reset()
            timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(timeCounter), userInfo: nil, repeats: true)
            endTimer = Timer.scheduledTimer(timeInterval: 30, target: self, selector: #selector(doThis), userInfo: nil, repeats: false)
          
        }
    }
    
    @objc func endQuiz() {
        if !buttonView.isHidden {
            answeredQuestionsNum += 1
            updateData()
        }

//        updateData()
//        getData()
        callBack?(categoryArray)
        navigationController?.popViewController(animated: true)
    }
    
    func updateData() {
        category.updateCategoryPercent(percent: calculate(),
                                       filterText: selectedCategory ?? "",
                                       count: Int16(answeredQuestionsNum))
        helper.updatePoints(points: Int(points))
        
        getData()
    }
    
    func showEndAlert() {
        let alert = UIAlertController(title: "Quiz finished", message: "You have completed \(questionArray.count) questions", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
            self.navigationController?.popViewController(animated: true)
        }))
        present(alert, animated: true, completion: nil)
    }

    @IBAction func firstSelected(_ sender: Any) {
        answerReveal(answer: optionsArray[answeredQuestionsNum].options ?? "")
    }
    
    @IBAction func secondSelected(_ sender: Any) {
        answerReveal(answer: optionsArray[answeredQuestionsNum].option2 ?? "")
    }
    
    @IBAction func thirdSelected(_ sender: Any) {
        answerReveal(answer: optionsArray[answeredQuestionsNum].option3 ?? "")
    }
    
    @IBAction func nextQuestion(_ sender: Any) {
        if answeredQuestionsNum < questionArray.count - 1 {
            answeredQuestionsNum += 1
            time = 30
            quizStart()
        } else {
            showEndAlert()
        }
        updateData()
        print("points \(points)")
    }
}

extension QuizController {
    func warn() {
        if answeredQuestionsNum == 20 {
            let alert = UIAlertController(title: "Quiz finished", message: "You have completed \(questionArray.count) questions", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { _ in
                self.navigationController?.popViewController(animated: true)
            }))
            present(alert, animated: true, completion: nil)
        }
    }
    
    @objc func doThis() {
        hide()
        buttonView.isHidden = false
        buttonViewShade.isHidden = false
        secondOptionView.isUserInteractionEnabled = false
        secondOption.textColor = UIColor.red
        secondOption.text = questionArray[answeredQuestionsNum].answer
        timer.invalidate()
    }
    
    func answerReveal(answer: String) {
        if answer == questionArray[answeredQuestionsNum].answer {
            hide()
            secondOption.textColor = UIColor.green
            secondOption.text = "Correct"
            buttonView.isHidden = false
            buttonViewShade.isHidden = false
            countPoints()
        } else {
            hide()
            secondOption.textColor = UIColor.red
            secondOption.text = "Wrong"
            buttonView.isHidden = false
            buttonViewShade.isHidden = false
        }
        endTimer.invalidate()
        timer.invalidate()
        secondOptionView.isUserInteractionEnabled = false
    }
    
    func reset() {
        firstOptionView.isHidden = false
        firstOptionViewShade.isHidden = false
        thirdOptionView.isHidden = false
        thirdOptionViewShade.isHidden = false
        secondOptionView.isUserInteractionEnabled = true
        buttonView.isHidden = true
        buttonViewShade.isHidden = true
        secondOption.textColor = UIColor.label
    }
    
    func hide() {
        firstOptionView.isHidden = true
        firstOptionViewShade.isHidden = true
        thirdOptionView.isHidden = true
        thirdOptionViewShade.isHidden = true
    }
    
    func countPoints() {
        points += questionArray[answeredQuestionsNum].poitns
    }
    
    func calculate() -> Double {
//        let nums = count + 1
        percent = Double(answeredQuestionsNum) / Double(questionArray.count)
        return percent
    }
}
