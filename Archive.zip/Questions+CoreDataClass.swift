//
//  Questions+CoreDataClass.swift
//  QuizGameMidApp
//
//  Created by Elsever on 07.01.25.
//
//

import Foundation
import CoreData

@objc(Questions)
public class Questions: NSManagedObject {

}
