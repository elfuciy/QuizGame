//
//  OptionsData+CoreDataClass.swift
//  QuizGameMidApp
//
//  Created by Elsever on 02.01.25.
//
//

import Foundation
import CoreData

@objc(OptionsData)
public class OptionsData: NSManagedObject {

}
