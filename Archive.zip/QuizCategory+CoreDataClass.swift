//
//  QuizCategory+CoreDataClass.swift
//  QuizGameMidApp
//
//  Created by Elsever on 11.01.25.
//
//

import Foundation
import CoreData

@objc(QuizCategory)
public class QuizCategory: NSManagedObject {

}
