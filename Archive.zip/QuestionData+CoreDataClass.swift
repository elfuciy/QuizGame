//
//  QuestionData+CoreDataClass.swift
//  QuizGameMidApp
//
//  Created by Elsever on 01.01.25.
//
//

import Foundation
import CoreData

@objc(QuestionData)
public class QuestionData: NSManagedObject {

}
